#pragma once
#include <iostream>
using namespace std;
#ifndef VIGENERECIPHER_H
#define VIGENERECIPHER_H
string Vigenere_Encode(string s,string key);
string Vigenere_Dncode(string s,string key);
#endif
#pragma once
